using UnityEngine;

[CreateAssetMenu(menuName = "Scriptable Objects/Flow/Flow State")]
public class FlowState : ScriptableObject
{
}